
const franc = require("franc");
const langs = require("langs");
const colors = require("colors");
const input = process.argv[2];
const LangCode = franc(input);
if(LangCode==="und"){
    console.log("Your Sample language is not correct.".red);
}
else{
    const Language = langs.where("3",LangCode);
    console.log(`Our best guess is : ${Language.name}`.rainbow);
}