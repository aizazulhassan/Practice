const express = require("express");
const app = express();
app.use(((req,res))=>{
    console.log("We got a new request.");
    console.dir(req);
})
app.listen(8080 => {
    console.log("Listening on Port 3000.");
})