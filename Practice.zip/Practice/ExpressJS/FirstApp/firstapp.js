const express = require("express");
const app = express();
app.listen(8080,()=> {
    console.log("Listening on Port 3000.");
})
// app.use((req,res)=>{
//     console.log("We got a new request.");
//     res.send('<h1>I got your request and this is a response.</h1>')
// })
app.get('/',(req,res)=>{
    res.send("<h1>This is the HOME Page.</h1>")
})
app.get('/r/:subreddits',(req,res)=>{
    const {subreddits}=req.params;
    res.send(`<h1>This is ${subreddits} Subreddit.</h1>`)
})
app.get('/r/:subreddits/:id',(req,res)=>{
    const {subreddits,id}= req.params;
    res.send(`<h1>Viewing ${id}:id & ${subreddits} Subreddit. </h1>`)
})
app.get('/dogs',(req,res)=>{
    res.send("<h1>D for Doggie .. WOOFie</h1>")
})
app.get('/search',(req,res)=>{
    const {query} = req.query;
    if(!query){
        res.send("Nothing found if nothing search.")
    }
    res.send(`<h1>User search for ${query}</h1>`)
})
app.get('/cats',(req,res)=>{
    res.send("<h1>C for Cats .. Meow</h1>")
})
app.get('*',(req,res)=>{
    res.send("<h1>I don't know this address.</h1>")
})
