const square = x => x*x;
const Pi = 3.14159;
const add = (x,y)=> (x+y);
//All the Modules which we defines before are exported in another js.file
module.exports.square=square;
module.exports.Pi=Pi;
module.exports.add=add;