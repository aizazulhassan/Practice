const jokes = require("give-me-a-joke");
var colors = require("colors");
jokes.getRandomDadJoke (function(joke) {
    console.log(joke.rainbow);
});
