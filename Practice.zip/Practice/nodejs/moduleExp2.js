const Math = require('./moduleExp1');
console.log(Math.square(5));
const Persons= require('./RqrdDir');
console.log(Persons);