const Person1 = require("./Person1");
const Person2 = require("./Person2");
const Person3 = require("./Person3");

const allPerson = [Person1, Person2,Person3];
// console.log(allPerson);

module.exports(allPerson);
