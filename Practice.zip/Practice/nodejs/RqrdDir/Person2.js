module.exports={
    name : 'Jawad',
    color: 'Shdeed'
}