module.exports={
    name : 'Wajee',
    color: 'Red'
}