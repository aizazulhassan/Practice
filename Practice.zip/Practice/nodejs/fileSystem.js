const fs = require('fs');
// console.log(fs);
// fs.mkdir('Dog', { recursive: true }, (err) => {
//     console.log("I am in callback..");
//     if (err) throw err;
//   });
//   console.log("I am after Mkdir Call Back");
 
// fs.mkdirSync('Cats');
const FName = process.argv[2] || 'Project';
fs.mkdirSync(FName);
fs.writeFileSync(`${FName}/index.html`);
fs.writeFileSync(`${FName}/styles.css`);
fs.writeFileSync(`${FName}/app.js`);