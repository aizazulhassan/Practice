const args = process.argv.slice(2); // It will remove first two lines of paths.
// for(let arg of args){
//     console.log(`Hi there, ${arg}`);
// }
for(let arg of args){
    console.log(`Hey Boi,${arg}`);
}